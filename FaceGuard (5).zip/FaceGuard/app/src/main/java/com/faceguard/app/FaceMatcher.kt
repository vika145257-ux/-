package com.faceguard.app

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.sqrt

/**
 * Turns a cropped face into an embedding using a MobileFaceNet TFLite model.
 * Expected model: input 1x112x112x3 float, output 1xN float (usually N = 192).
 * Put the file at app/src/main/assets/mobilefacenet.tflite
 */
class FaceMatcher(ctx: Context) {
    private val interpreter: Interpreter
    private val outDim: Int

    init {
        val fd = ctx.assets.openFd(MODEL)
        val buf = FileInputStream(fd.fileDescriptor).channel
            .map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
        interpreter = Interpreter(buf, Interpreter.Options().setNumThreads(2))
        outDim = interpreter.getOutputTensor(0).shape()[1]
    }

    fun embed(face: Bitmap): FloatArray {
        val bmp = Bitmap.createScaledBitmap(face, SIZE, SIZE, true)
        val input = ByteBuffer.allocateDirect(4 * SIZE * SIZE * 3).order(ByteOrder.nativeOrder())
        val px = IntArray(SIZE * SIZE)
        bmp.getPixels(px, 0, SIZE, 0, 0, SIZE, SIZE)
        for (p in px) {
            input.putFloat((((p shr 16) and 0xFF) - 127.5f) / 128f)
            input.putFloat((((p shr 8) and 0xFF) - 127.5f) / 128f)
            input.putFloat(((p and 0xFF) - 127.5f) / 128f)
        }
        input.rewind()
        val out = Array(1) { FloatArray(outDim) }
        interpreter.run(input, out)
        return normalize(out[0])
    }

    fun close() = interpreter.close()

    companion object {
        private const val MODEL = "mobilefacenet.tflite"
        private const val SIZE = 112

        private fun normalize(v: FloatArray): FloatArray {
            var n = 0f
            for (x in v) n += x * x
            n = sqrt(n).coerceAtLeast(1e-6f)
            return FloatArray(v.size) { v[it] / n }
        }

        /** Both vectors are already L2-normalised, so the dot product is the cosine similarity. */
        fun cosine(a: FloatArray, b: FloatArray): Float {
            var d = 0f
            for (i in a.indices) d += a[i] * b[i]
            return d
        }
    }
}
